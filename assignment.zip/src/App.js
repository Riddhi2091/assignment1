import './App.css';
import WasteCollecton from './components/WasteCollecton';

function App() {
  return (
    <div className="App">
      <WasteCollecton />
    </div>
  );
}

export default App;
